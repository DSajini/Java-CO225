/*
Question 1- Instead of doing all the steps of matrix operation in the main method,threads can be used to devide the steps of the operation.
            And they can be run parallel.
			Here ,in this operation threads are created rowwise.

Question 2-Here ,thread array of size 3 is created.In general,number of threads is equal to the number of rows in array a.

Question 3-Each thread has a specific task and it is defined in run method.
           Each thread calculates the sum of the matrix multiplication of relevent row of matrix a and relevent column of mtrix b.
           Then matrix c is updated using this calculated sum.

Question 4-Thread synchronization is the concurrent execution of two or more threads.
           It avoids conflicts which may arise when parallel-running threads attempt to modify a common variable at the same time.        

*/

 public class Matrix extends Thread { 

    private static int [][] a; 
    private static int [][] b; 
    private static int [][] c; 
    int row;
    int z1;
    int y;

    /* You might need other variables as well */

    public Matrix(int [][]a,int[][]b,int[][]c,int row,int y,int z1) { // need to change this, might need some information 
    	a=this.a;
    	b=this.b;
    	c=this.c;
    	row=this.row;
    	y=this.y;
    	z1=this.z1;

    }

    public static int [][] multiply(int [][] a, int [][] b) {

	/* check if multipication can be done, if not 
	 * return null 
	 * allocate required memory 
	 * return a * b
	 */

	int x = a.length; 
	int y = b[0].length; 

	int z1 = a[0].length; 
	int z2 = b.length; 

	if(z1 != z2) { 
	    System.out.println("Cannnot multiply");
	    return null;
	}

	int [][] c = new int [x][y]; 
	int i, j, k, s; 

	for(i=0; i<x; i++) 
	    for(j=0; j<y; j++) {
		for(s=0, k=0; k<z1; k++) 
		    s += a[i][k] * b[k][j];
		c[i][j] = s;
	    }

	
//create threads
	Matrix[] t= new Matrix[x];

	for(i=0;i<x;i++){
		t[i]=new Matrix(a,b,c,i,y,z1);
		t[i].start();
	}
	for(i=0;i<x;i++){


		try{
			t[i].join();
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
		
	


	return c; 
    }


    
//creating  run method for threads
    public void run(){
    	int k,s=0,j;
    	for(j=0; j<y; j++) {
		for( k=0; k<z1; k++){ 
		    s += a[row][k] * b[k][j];
    	}
		c[row][j] = s;
	}
	}
    

}

